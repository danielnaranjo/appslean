'use strict';

/**
 * @ngdoc function
 * @name calculatorApp.controller:LawyersCtrl
 * @description
 * # LawyersCtrl
 * Controller of the calculatorApp
 */
app.controller('LawyersCtrl', function ($scope, Data) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
