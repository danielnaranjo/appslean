'use strict';

/**
 * @ngdoc function
 * @name calculatorApp.controller:SignupCtrl
 * @description
 * # SignupCtrl
 * Controller of the calculatorApp
 */
app.controller('SignupCtrl', function ($scope, Data) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
