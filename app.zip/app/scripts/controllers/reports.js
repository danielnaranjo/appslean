'use strict';

/**
 * @ngdoc function
 * @name calculatorApp.controller:ReportsCtrl
 * @description
 * # ReportsCtrl
 * Controller of the calculatorApp
 */
app.controller('ReportsCtrl', function ($scope, Data) {
        $scope.data = [{
    	'name':'Daniel Naranjo',
    	'email':'d@d.co',
    	'type':'NETK - Office'
    },{
    	'name':'Daniel Naranjo',
    	'email':'d@d.co',
    	'type':'NETK - Office'
    },{
    	'name':'Daniel Naranjo',
    	'email':'d@d.co',
    	'type':'NETK - Office'
    },{
    	'name':'Daniel Naranjo',
    	'email':'d@d.co',
    	'type':'NETK - Office'
    }];
  });
