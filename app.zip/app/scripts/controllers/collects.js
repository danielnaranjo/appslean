'use strict';

/**
 * @ngdoc function
 * @name calculatorApp.controller:CollectsCtrl
 * @description
 * # CollectsCtrl
 * Controller of the calculatorApp
 */
app.controller('CollectsCtrl', function ($scope, Data) {
  	// $scope.update = function(){
  	// 	$scope.cheque=0;
  	// 	if($scope.collects.payment===3) {
  	// 		$scope.cheque = $scope.collects.payment;	
  	// 	} 
  	// 	console.log($scope.collects.payment);
   //  };
  });
