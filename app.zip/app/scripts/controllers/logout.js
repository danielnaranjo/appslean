'use strict';

/**
 * @ngdoc function
 * @name calculatorApp.controller:LogoutCtrl
 * @description
 * # LogoutCtrl
 * Controller of the calculatorApp
 */
app.controller('LogoutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
