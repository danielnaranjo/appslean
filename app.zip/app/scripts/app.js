'use strict';

/**
 * @ngdoc overview
 * @name calculatorApp
 * @description
 * # calculatorApp
 *
 * Main module of the application.
 */
var app = angular.module('calculatorApp', [
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'googlechart',
    'toaster',
    'ngAnimate',
    'ui.bootstrap'
  ]);

app.config(function ($routeProvider) {
    $routeProvider
      // .when('/', {
      //   templateUrl: 'views/login.html',
      //   controller: 'LoginCtrl',
      //   role: '0'
      // })
      .when('/login', {
        templateUrl: 'views/login.html',
        controller: 'LoginCtrl'
      })
      .when('/logout', {
        templateUrl: 'views/logout.html',
        controller: 'LogoutCtrl'
      })
      .when('/signup', {
        templateUrl: 'views/signup.html',
        controller: 'LoginCtrl'
      })
      .when('/main', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      })
      .when('/reports', {
        templateUrl: 'views/reports.html',
        controller: 'ReportsCtrl'
      })
      .when('/lawyers', {
        templateUrl: 'views/lawyers.html',
        controller: 'LawyersCtrl'
      })
      .when('/collects', {
        templateUrl: 'views/collects.html',
        controller: 'CollectsCtrl'
      })
      .otherwise({
        redirectTo: '/login'
      })
  })  
  .run(function($rootScope, $location, $http, Data) {
    $rootScope.$on("$routeChangeStart",function (event, next, current){
      $rootScope.authenticated = false;
      Data.get('session').then(function (results) {
        // Check data received!
        // console.log(JSON.stringify(results));
        if (results.uid) {
          $rootScope.authenticated = true;
          $rootScope.uid = results.uid;
          $rootScope.name = results.name;
          $rootScope.email = results.email;
          console.log('There is data');
        } else {
          var nextUrl = next.$$route.originalPath;
          console.log(nextUrl);
          if (nextUrl == '/signup' || nextUrl == '/login') {
            // none behavior
            console.log('Route 66');
          } else {
            $location.path("/login");
            console.log('Route is blocked by Men at work');
          }
        }
      });
    });
  });