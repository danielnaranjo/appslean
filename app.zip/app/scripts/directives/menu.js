'use strict';

/**
 * @ngdoc directive
 * @name calculatorApp.directive:menu
 * @description
 * # menu
 */
app.directive('menu', function() {
  return {
    templateUrl: 'views/menu.html'
  };
});